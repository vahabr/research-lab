Run: python kalman_pd_simulation.py
Outputs saved under /mnt/data (CSVs + PNGs). Deterministic seeds.
