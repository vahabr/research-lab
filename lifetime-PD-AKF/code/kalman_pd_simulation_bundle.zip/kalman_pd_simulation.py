
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
OUTDIR=Path("/mnt/data"); OUTDIR.mkdir(parents=True, exist_ok=True)
RATINGS=["A","B","C","D"]; IDX={r:i for i,r in enumerate(RATINGS)}; T_DEFAULT=20; N_DEFAULT=10000
def set_seed(seed): import numpy as np; np.random.seed(seed); return np.random.default_rng(seed)
def build_P_TTC(): import numpy as np; return np.array([[0.975,0.022,0.002,0.001],[0.030,0.935,0.030,0.005],[0.010,0.060,0.915,0.015],[0.000,0.000,0.000,1.000]],float)
def _baseline_paths(T): import numpy as np; t=np.arange(T); return 0.5+0.3*np.sin(2*np.pi*t/12), 5.0+0.2*np.cos(2*np.pi*(t+3)/10)
def _stress_paths(T): import numpy as np; t=np.arange(T); g=0.6-0.8*np.exp(-t/2.0); g[:4]-=0.8; u=4.5+1.8*(1-np.exp(-t/4.0)); return g,u
def _pandemic_paths(T): import numpy as np; t=np.arange(T); g=0.5*np.ones(T); g[0:2]=-2.0; g[2]=-0.5; u=4.2*np.ones(T); u[0:3]=5.5; u[3:6]=5.0; return g,u
def macro_index_from_gdp_unemp(G,U):
    import numpy as np
    def z(x): x=np.asarray(x); mu=x.mean(); sd=x.std(ddof=0); sd=sd if sd>1e-12 else 1.0; return (x-mu)/sd
    return 0.5*z(G)-0.5*z(U)
def gen_macro_forecasts_and_realised(scn,T=20,rng=None):
    import numpy as np
    if rng is None: rng=np.random.default_rng()
    scn=scn.lower(); 
    if scn=="baseline": g,u=_baseline_paths(T)
    elif scn=="stress": g,u=_stress_paths(T)
    else: g,u=_pandemic_paths(T)
    gr=g+rng.normal(0.0,0.2,size=T); ur=u+rng.normal(0.0,0.2,size=T)
    if scn=="pandemic" and T>=4: gr[3]+=2.5; ur[3]-=0.8
    return {"gdp_forecast":g,"unemp_forecast":u,"gdp_realised":gr,"unemp_realised":ur,"M_hat":macro_index_from_gdp_unemp(g,u),"M_real":macro_index_from_gdp_unemp(gr,ur)}
def _build_betas():
    import numpy as np; b=np.zeros((4,4)); b[0,1]=2.0; b[0,2]=2.5; b[0,3]=3.0; b[1,2]=1.5; b[1,3]=2.0; b[2,3]=1.2; b[1,0]=-b[0,1]; b[2,1]=-b[1,2]; b[2,0]=-b[0,2]; return b
def pit_overlay(P,M,b):
    import numpy as np; W=P*np.exp(b*M); 
    for i in range(4):
        if i==3: W[i,:]=0.0; W[i,3]=1.0
        else: s=W[i,:].sum(); W[i,:]=P[i,:] if s<=0 else W[i,:]/s
    return W
def kalman_naive(M,rho=0.90,Q=None,R=0.25):
    import numpy as np; T=len(M); Q=(1-rho**2) if Q is None else Q; m=0.0; P=1.0; out=np.zeros(T)
    for t in range(T):
        mp=rho*m; Pp=rho*P*rho+Q; S=Pp+R; K=Pp/S; m=mp+K*(M[t]-mp); P=(1-K)*Pp; out[t]=m
    return out
def kalman_anchored(M,T_anchor=20,rho=0.90,Q=None,R=0.25,sigma_star2_pre=0.25):
    import numpy as np; T=len(M); Q=(1-rho**2) if Q is None else Q; m=0.0; P=1.0; H=np.array([[1.0],[1.0]]); out=np.zeros(T)
    for t in range(T):
        mp=rho*m; Pp=rho*P*rho+Q; y=np.array([M[t],0.0]); Raug=np.diag([R,sigma_star2_pre]) if t<T_anchor else np.diag([R,1e-12])
        S=H@np.array([[Pp]])@H.T+Raug; K=(np.array([[Pp]])@H.T)@np.linalg.inv(S); innov=y-(H.flatten()*mp); m=mp+(K@innov)[0]; P=(1-(K@H)[0,0])*Pp; out[t]=m
    return out
def propagate_distribution(pi0,Pts):
    import numpy as np; T=len(Pts); pi=np.zeros((T+1,4)); pi[0,:]=pi0; cur=pi0.copy()
    for t in range(T): cur=cur@Pts[t]; pi[t+1,:]=cur
    return pi
def compute_pd_series(pi): return pi[:,3]
def run_experiment(scn,method,N=10000,T=20,seed=20250821):
    import numpy as np, pandas as pd, matplotlib.pyplot as plt
    rng=set_seed(seed+hash((scn,method))%10000); pi0=np.array([0.45,0.40,0.15,0.00]); P=build_P_TTC(); bet=_build_betas()
    m=gen_macro_forecasts_and_realised(scn,T=T,rng=rng); Mhat=m["M_hat"]; Mreal=m["M_real"]
    if method=="raw": Mest=Mreal.copy()
    elif method=="naive": Mest=kalman_naive(Mhat)
    else: Mest=kalman_anchored(Mhat,T_anchor=T)
    Pts=[pit_overlay(P,Mest[t],bet) for t in range(T)]
    pi=propagate_distribution(pi0,Pts); Y=compute_pd_series(pi)
    Pneu=[P.copy() for _ in range(T)]; pi_ttc=propagate_distribution(pi0,Pneu); Yttc=compute_pd_series(pi_ttc)
    # Save CSVs
    pd.DataFrame({"t":range(1,T+1),"M_forecast":Mhat,"M_realised":Mreal,"M_estimate":Mest}).to_csv(OUTDIR/f"macro_paths_{scn}_{method}.csv",index=False)
    pd.DataFrame({"t":range(0,T+1),"Y_t":Y,"Y_ttc":Yttc}).to_csv(OUTDIR/f"pd_term_structures_{scn}_{method}.csv",index=False)
    rows=[]; 
    for t in range(T):
        for i,ri in enumerate(RATINGS):
            for j,rj in enumerate(RATINGS): rows.append({"t":t+1,"from":ri,"to":rj,"P":Pts[t][i,j]})
    pd.DataFrame(rows).to_csv(OUTDIR/f"transition_matrices_{scn}_{method}.csv",index=False)
    # Macro figure
    fig=plt.figure(); q=np.arange(1,T+1); plt.plot(q,Mhat,label="Forecast (M̂)"); plt.plot(q,Mreal,label="Realised M"); plt.plot(q,Mest,label=f"Estimate: {method}")
    plt.axhline(0.0); plt.xlabel("Quarter"); plt.ylabel("Macro index (z)"); plt.title(f"Macro filter: {scn} × {method}"); plt.legend()
    fig.savefig(OUTDIR/f"macro_filter_{scn}_{method}.png",bbox_inches="tight"); plt.close(fig)
    return {"Y_t":Y,"Y_ttc":Yttc,"files":{"macro_paths":str(OUTDIR/f"macro_paths_{scn}_{method}.csv"),"pd_term_structures":str(OUTDIR/f"pd_term_structures_{scn}_{method}.csv")}}
def _pd_bands_figure(res_per_scn,method,T=20):
    import numpy as np, matplotlib.pyplot as plt
    t=np.arange(0,T+1); fig=plt.figure(); any_key=next(iter(res_per_scn)); Yttc=res_per_scn[any_key]["Y_ttc"]; plt.plot(t,Yttc,label="TTC baseline")
    for scn,res in res_per_scn.items(): plt.plot(t,res["Y_t"],label=f"{scn}")
    plt.xlabel("Quarter"); plt.ylabel("Cumulative PD (π_t[D])"); plt.title(f"PD term-structure bands across scenarios — {method}"); plt.legend()
    path=OUTDIR/f"pd_bands_{method}.png"; fig.savefig(path,bbox_inches="tight"); plt.close(fig); return str(path)
def variance_across_scenarios(Y_by_scn):
    import numpy as np, pandas as pd; Ys=np.stack([v for v in Y_by_scn.values()],axis=0); return pd.DataFrame({"t":np.arange(Ys.shape[1]),"var_Y_t":Ys.var(axis=0,ddof=0)})
def monte_carlo_loss_volatility(scn,method,pi0,P,bet,base_forecasts,n_rep=200,seed=20250821):
    import numpy as np; rng=np.random.default_rng(seed+hash((scn,method))%10000); T=len(base_forecasts["M_hat"]); YT=np.zeros(n_rep)
    for r in range(n_rep):
        gf=base_forecasts["gdp_forecast"]; uf=base_forecasts["unemp_forecast"]
        gr=gf+rng.normal(0.0,0.2,size=T); ur=uf+rng.normal(0.0,0.2,size=T)
        if scn=="pandemic" and T>=4: gr[3]+=2.5; ur[3]-=0.8
        Mhat=macro_index_from_gdp_unemp(gf,uf); Mreal=macro_index_from_gdp_unemp(gr,ur)
        if method=="raw": Meff=Mreal
        elif method=="naive": Meff=kalman_naive(Mhat)
        else: Meff=kalman_anchored(Mhat,T_anchor=T)
        Pts=[pit_overlay(P,Meff[t],bet) for t in range(T)]; pi=propagate_distribution(pi0,Pts); YT[r]=pi[-1,3]
    return {"mean":float(YT.mean()),"std":float(YT.std(ddof=0)),"samples":YT}
def plot_scenario_method_pd_comparison(all_results,scn,T=20):
    import numpy as np, matplotlib.pyplot as plt
    fig=plt.figure(); 
    for m in ["raw","naive","anchored"]:
        plt.plot(np.arange(0,T+1),all_results[m][scn]["Y_t"],label=m)
    plt.plot(np.arange(0,T+1),all_results["anchored"][scn]["Y_ttc"],linestyle="--",label="TTC baseline")
    plt.xlabel("Quarter"); plt.ylabel("Cumulative PD (Y_t)"); plt.title(f"Lifetime PD term structures — {scn}"); plt.legend()
    fig.savefig(OUTDIR/f"pd_term_structures_{scn}_methods.png",bbox_inches="tight"); plt.close(fig)
def plot_anchoring_effect(all_results,scn,T=20):
    import pandas as pd, matplotlib.pyplot as plt
    df_n=pd.read_csv(all_results["naive"][scn]["files"]["macro_paths"]); df_a=pd.read_csv(all_results["anchored"][scn]["files"]["macro_paths"]); df=df_n.merge(df_a,on="t",suffixes=("_naive","_anchored"))
    t=df["t"].values; Mhat=df["M_forecast_naive"].values; Mreal=df["M_realised_naive"].values; Mna=df["M_estimate_naive"].values; Man=df["M_estimate_anchored"].values
    fig=plt.figure(); plt.plot(t,Mhat,label="Forecast (M̂)"); plt.plot(t,Mreal,label="Realised M"); plt.plot(t,Mna,label="Naïve KF"); plt.plot(t,Man,label="Anchored KF"); plt.axhline(0.0)
    plt.xlabel("Quarter"); plt.ylabel("Macro index (z)"); plt.title(f"Anchoring effect — {scn}"); plt.legend(); fig.savefig(OUTDIR/f"anchoring_effect_{scn}.png",bbox_inches="tight"); plt.close(fig)
def plot_uplift_against_ttc(all_results,scn,T=20):
    import numpy as np, matplotlib.pyplot as plt
    Yttc=all_results["anchored"][scn]["Y_ttc"]; fig=plt.figure()
    for m in ["raw","naive","anchored"]:
        uplift=all_results[m][scn]["Y_t"]-Yttc; plt.plot(np.arange(0,T+1),uplift,label=m)
    plt.axhline(0.0); plt.xlabel("Quarter"); plt.ylabel("PD uplift vs TTC"); plt.title(f"TTC vs PIT uplift — {scn}"); plt.legend()
    fig.savefig(OUTDIR/f"uplift_{scn}.png",bbox_inches="tight"); plt.close(fig)
def bar_mc_lifetime_pd(df_mc,scn):
    import numpy as np, matplotlib.pyplot as plt
    sub=df_mc[df_mc["scenario"]==scn].copy(); order=["raw","naive","anchored"]; sub["method"]=pd.Categorical(sub["method"],categories=order,ordered=True); sub=sub.sort_values("method")
    x=np.arange(len(order)); means=sub["YT_mean"].values; stds=sub["YT_std"].values; fig=plt.figure(); plt.bar(x,means,yerr=stds,capsize=4); plt.xticks(x,order); plt.ylabel("Lifetime PD at T (mean)")
    plt.title(f"Lifetime PD (200 MC reps) — {scn}"); plt.grid(axis="y",linestyle=":"); fig.savefig(OUTDIR/f"mc_lifetime_pd_{scn}.png",bbox_inches="tight"); plt.close(fig)
def box_and_violin_from_samples(df,scn):
    import numpy as np, matplotlib.pyplot as plt
    ms=["raw","naive","anchored"]; fig=plt.figure(); plt.boxplot([df[m] for m in ms],labels=ms,showfliers=False)
    for i,m in enumerate(ms,1): x=np.random.normal(i,0.06,size=len(df)); plt.plot(x,df[m].values,linestyle="",marker="o",alpha=0.4)
    plt.ylabel("Lifetime PD at T"); plt.title(f"Distribution of lifetime PD (200 MC reps) — {scn}"); fig.savefig(OUTDIR/f"mc_box_dots_{scn}.png",bbox_inches="tight"); plt.close(fig)
    fig2=plt.figure(); plt.boxplot([df[m] for m in ms],labels=ms,notch=True,showfliers=False); plt.ylabel("Lifetime PD at T"); plt.title(f"Notched boxplot — {scn} (200 MC reps)")
    fig2.savefig(OUTDIR/f"mc_box_notched_{scn}.png",bbox_inches="tight"); plt.close(fig2)
    fig3=plt.figure(); plt.violinplot([df[m] for m in ms],showmeans=True,showmedians=True); plt.xticks(range(1,len(ms)+1),ms); plt.ylabel("Lifetime PD at T"); plt.title(f"Violin plot — {scn} (200 MC reps)")
    fig3.savefig(OUTDIR/f"mc_violin_{scn}.png",bbox_inches="tight"); plt.close(fig3)
def main():
    seed=20250821; rng=set_seed(seed)
    scns=["baseline","stress","pandemic"]; methods=["raw","naive","anchored"]; pi0=np.array([0.45,0.40,0.15,0.00]); P=build_P_TTC(); bet=_build_betas()
    all_results={m:{} for m in methods}
    for m in methods:
        for s in scns: all_results[m][s]=run_experiment(s,m,seed=seed)
    # Bands & variance
    import pandas as pd
    var_tabs=[]
    for m in methods:
        _pd_bands_figure(all_results[m],m,T_DEFAULT)
        Y_by={s:all_results[m][s]["Y_t"] for s in scns}
        dfv=variance_across_scenarios(Y_by); dfv.insert(0,"method",m); var_tabs.append(dfv)
    pd.concat(var_tabs,ignore_index=True).to_csv(OUTDIR/"variance_Y_across_scenarios.csv",index=False)
    # MC
    rows=[]
    for m in methods:
        for s in scns:
            bf=gen_macro_forecasts_and_realised(s,T=T_DEFAULT,rng=rng)
            mc=monte_carlo_loss_volatility(s,m,pi0,P,bet,bf,n_rep=200,seed=seed)
            rows.append({"scenario":s,"method":m,"YT_mean":mc["mean"],"YT_std":mc["std"]})
            path=OUTDIR/f"mc_samples_YT_{s}.csv"; dfm=pd.DataFrame({m:mc["samples"]})
            if path.exists(): old=pd.read_csv(path); pd.concat([old,dfm],axis=1).to_csv(path,index=False)
            else: dfm.to_csv(path,index=False)
    dfmc=pd.DataFrame(rows); dfmc.to_csv(OUTDIR/"lifetime_loss_volatility_mc.csv",index=False)
    # Extras
    for s in scns:
        bar_mc_lifetime_pd(dfmc,s); 
        samp_path=OUTDIR/f"mc_samples_YT_{s}.csv"; df=pd.read_csv(samp_path)
        cons={}
        for m in ["raw","naive","anchored"]:
            mcols=[c for c in df.columns if c==m]
            cons[m]=df[mcols[0]].values if len(mcols)>=1 else np.full(200,np.nan)
        dff=pd.DataFrame(cons); dff.to_csv(samp_path,index=False); box_and_violin_from_samples(dff,s)
        plot_scenario_method_pd_comparison(all_results,s,T_DEFAULT); plot_anchoring_effect(all_results,s,T_DEFAULT); plot_uplift_against_ttc(all_results,s,T_DEFAULT)
    # Macro overview
    q=np.arange(1,T_DEFAULT+1)
    # Forecasts only
    fig=plt.figure()
    for s in scns:
        mh=gen_macro_forecasts_and_realised(s,T=T_DEFAULT)["M_hat"]; plt.plot(q,mh,label=f"{s} (M̂)")
    plt.axhline(0.0); plt.xlabel("Quarter"); plt.ylabel("Macro index (z)"); plt.title("Forecasted macro index across scenarios"); plt.legend()
    fig.savefig(OUTDIR/"macro_forecasts_all.png",bbox_inches="tight"); plt.close(fig)
    print("Done.")
if __name__=="__main__": main()
